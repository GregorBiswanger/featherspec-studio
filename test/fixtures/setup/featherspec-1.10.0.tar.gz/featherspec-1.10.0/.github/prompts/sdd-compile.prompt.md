---
name: sdd-compile
description: Final readiness check — verdict, evidence and spec fidelity per acceptance criterion, tests, rule check, docs sync.
argument-hint: "[path-to-spec.md] [runTests:true|false]"
---

# /sdd-compile

Follow [`.claude/commands/sdd-compile.md`](../../.claude/commands/sdd-compile.md) exactly — read that file
first and treat it as your instructions for this turn. It is the single source for this
workflow; this file only points at it and holds no rules of its own.

Anything the user typed after the command is the argument the workflow refers to.
