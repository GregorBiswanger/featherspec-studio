<div align="center">

<img src="featherspec-logo.png" alt="FeatherSpec" width="320">

**Spec-driven development that works in Claude Code _and_ GitHub Copilot — from the same files.**

No CLI. No install. No dependencies. Markdown and folders.

[![Use this template](https://img.shields.io/badge/Use%20this%20template-2ea44f?style=for-the-badge&logo=github&logoColor=white)](https://github.com/GregorBiswanger/featherspec/generate)
[![Read the Wiki](https://img.shields.io/badge/Read%20the-Wiki-0b7cbb?style=for-the-badge&logo=readthedocs&logoColor=white)](https://github.com/GregorBiswanger/featherspec/wiki)
[![License: MIT](https://img.shields.io/badge/License-MIT-555?style=for-the-badge)](LICENSE)

</div>

---

A chat forgets. FeatherSpec doesn't.

You describe **what** you want, your agent turns it into a **spec** with testable acceptance
criteria, then into a **plan** of baby steps — and only then writes code. Spec, plan, decisions
and progress all live on disk as Markdown in your repository, so the next session, the next
teammate, and the next tool pick up exactly where you left off.

Thirteen `/sdd-*` commands drive that loop — identical in Claude Code and GitHub Copilot,
because both tools execute the **same files**.

Tracking work in Jira or GitHub Issues? One wizard answer links every spec to a ticket and every
status move to a transition — through the tracker access your tool already has, with no tracker
knowledge inside FeatherSpec. Solo developers answer `none` and never see it.

---

## Start in two minutes

*(These three steps are the greenfield path — adopting an existing repository? Jump to
[Already have a codebase?](#already-have-a-codebase).)*

### 1 · Get the template

Click **[Use this template](https://github.com/GregorBiswanger/featherspec/generate)** on GitHub — or clone it:

```bash
git clone https://github.com/GregorBiswanger/featherspec.git my-project
```

The clone brings this repository's commit history along with a remote pointing back here. For
your own project you want neither: delete the `.git` folder (`rm -rf .git`, or
`Remove-Item -Recurse -Force .git` in PowerShell) and run `git init`.

**Have Node.js?** Then `degit` saves you that cleanup — it downloads only the current file
state, so there is no history and no `.git` folder to detach in the first place:

```bash
npx degit GregorBiswanger/featherspec my-project
```

### 2 · Open it in your assistant

**Claude Code**

```bash
cd my-project
claude
```

`CLAUDE.md` imports `AGENTS.md` at session start, so the rules are always loaded. Type `/` and
the `sdd-` commands are there.

**GitHub Copilot (VS Code)**

Open **the project folder itself** — not a parent folder, or the slash commands won't show up.
Open Copilot Chat (<kbd>Ctrl</kbd>/<kbd>Cmd</kbd> + <kbd>Alt</kbd> + <kbd>I</kbd>), switch to
**Agent** mode, and optionally pick the **SpecDrivenAgent** persona. Type `/` — same commands,
same behaviour.

### 3 · Run the wizard once

```text
/sdd-setup
```

It asks which language your documentation should be written in (answer `English`, `Deutsch`,
`Français`, … — everything the workflow writes from then on follows it), then a handful of
questions about the project. It seeds the Memory Bank, captures a first architecture
snapshot, and agrees the working rules with you: the quality gate that runs after every
implementation step until it is clean, and the TDD working mode — proposed in plain
language, confirmed by you, never assumed. Its last question is where your tickets live —
GitHub, Jira, another tracker, or nowhere (the default) — recorded as `IssueTracker:` in
`AGENTS.md`. Answer it and every finished spec offers to become a ticket, and every lifecycle
move offers the matching transition, using whatever tracker access your tool already has
(`gh`, the GitHub or Atlassian MCP server). Skip it and nothing changes.

That is the entire installation. Nothing to build, nothing to run.

---

## Already have a codebase?

FeatherSpec adopts existing software as a first-class path — from a single service up to
large enterprise repositories: the scan's worklist gate is the cost dial (deep-scan the
core, defer the periphery, rescan later with a focus path).

**Step 0 — get the files into your repository.** An existing project does not start from
"Use this template"; copy the template's files in instead. Fetch the template next to your
project:

```bash
npx degit GregorBiswanger/featherspec featherspec-tmp
```

Then copy into your repo: `AGENTS.md`, `CLAUDE.md`, `.claude/`, `.github/prompts/`,
`.github/instructions/`, `.github/agents/`, `.specs/`, `.memory-bank/` — plus
`.vscode/settings.json` and the template's `.gitignore` entries (merge both if you already
have your own). Nothing else: no build, no dependencies.

**Then run `/sdd-setup` and answer *existing software*** — the wizard offers a deep
architecture scan that reads your code (recursively, with isolated scout agents), lets you
confirm the module boundaries it found, and distills a lean fingerprint into the
`architecture:` snapshot. It is resumable at any point, re-runnable whenever the snapshot
feels stale (`/sdd-architecture-scan`, optionally with a focus path), and it cleans up
after itself.

The payoff: agents jump straight to the right files instead of exploring — with verified
conventions and traps as grounds for better technical decisions — and the documentation can
never flood the context window: always loaded is only the ~200-line constitution, while
per-module depth lives in ≤ 40-line maps that load only when their module is touched.

And it keeps *what it can see* apart from *why it was meant that way*. An observed pattern
always carries an evidence path; its reason is recorded only when a source states it — an ADR,
a requirement, or you — and stays **unknown** when none does, instead of being filled with a
plausible guess that the next session inherits as fact. Where two documents give the assistant
incompatible reasons for the same thing, it keeps both and picks neither. You are asked about
an unknown reason once, bundled at the end of the scan, and "later" is a complete answer.
**And the behaviour itself?** The fingerprint says *where* things are; `/sdd-reverse-specify`
recovers *what the software already does* — from code, tests, contracts, or a technical plan
that was built without a spec. Point it at a file, a folder or a symbol, or let the wizard offer
it after the scan. It first proposes a map of capabilities in your users' words — never one spec
per class — then isolated scouts collect evidence for one capability at a time, and you are
walked through the doubts only: conflicts first, uncertain behaviour next, the rest as quick
confirmations. You are only asked whether the assistant understood what the software does today
— never what it should do, and never about something you could not have seen: a retry count or a
stored value is shown, not asked. Nothing becomes a spec without a human's yes, whatever could
harm or mislead a person is kept as a *finding* instead of a requirement, and what you confirm
lands as a normal `Baseline` spec in `.specs/done/`. No retrospective plans, no repository-wide
documentation dump — reconstruct what is about to change or must be protected, and defer the
rest at no cost.

The full walkthrough lives in the wiki:
[Adopting an Existing Codebase](https://github.com/GregorBiswanger/featherspec/wiki/Adopting-an-Existing-Codebase).

---

## Already running FeatherSpec? Updates are built in

Since v1.2.0 the template is versioned ([tags & releases](https://github.com/GregorBiswanger/featherspec/releases)),
and projects created from it update safely — however customized. Projects adopted **before**
v1.2.0 just copy two files from the current template into their repo:

- `.claude/commands/sdd-featherspec-update.md`
- `.github/prompts/sdd-featherspec-update.prompt.md` *(skip if you removed the Copilot half;
  restart VS Code afterwards if you kept it)*

Then run `/sdd-featherspec-update`. It detects your version (even unstamped and heavily
customized projects), fetches the latest release, previews every change before writing, and
migrates **around** your customizations instead of over them: your specs, Memory Bank and
edits are provably untouched, conflicts are asked — never decided — and a backup branch
guards the whole run. `/sdd-featherspec-update check` alone answers "which version am I on?".
Details: [Updating & Versioning](https://github.com/GregorBiswanger/featherspec/wiki/Updating-and-Versioning).

---

## Link specs to your issue tracker

Since 1.7.0. The spec stays the source of truth; the board stays what your team looks at.

1. **One answer.** `/sdd-setup` asks last: *Where do tickets live — GitHub, Jira, another
   tracker, or nowhere?* It writes `IssueTracker: jira` into `AGENTS.md` and, for Jira, your
   project key into the Memory Bank. No login, no token, nothing verified live.
2. **Two offers.** `/sdd-specify` ends with *Create a ticket for this spec?* and writes
   `**Ticket:** KAN-4` into the spec header. `/sdd-lifecycle` proposes *move → `active/` +
   KAN-4 → In Progress?* — one yes covers both. Done closes with a one-line comment,
   reactivation reopens.
3. **Zero knowledge.** The agent uses `gh`, the GitHub or Atlassian MCP server, or your
   tracker's own — so a Jira API change is never a FeatherSpec update.

Every write waits for your yes. A tracker that is down never blocks the flow: the spec is finished
anyway and the failure lands in its *Open points*. Since 1.10.0 the agent reads the ticket before
it writes: a ticket someone already moved is named, never silently overwritten, and
`/sdd-overview` offers to compare all tickets with the board. Set the `**Ticket:**` line by hand
to link an existing ticket. Setup per platform and the full behaviour:
[Issue Tracker Link](https://github.com/GregorBiswanger/featherspec/wiki/Issue-Tracker-Link).

---

## Work in parallel — subagents or several agents

Since 1.10.0. One plan, several workers, no server: the repository is the only shared state.

1. **Read the plan.** `/sdd-plan` looks for independent steps in every plan. They appear
   joined by `‖` under `## Stages`, each with its own files and its own test file — or the
   plan says why nothing can run side by side.
2. **Choose how — once.** The agent asks, says what each way changes and recommends one: in
   sequence, with **subagents** (it starts up to three `sdd-implementer` workers itself —
   exercised in Claude Code; the agent file for VS Code with GitHub Copilot ships too, but
   that path has not been run end to end yet), or with **other agents** — it prints one line per
   step,
   `Implement T-003 of <plan> as a parallel worker.`, for you to paste into a second
   session, another tool or model, or a git worktree.
3. **One writer.** A worker writes only its step's files and one return note. The main
   session re-runs every check on the combined tree, ticks the steps and deletes the notes —
   plan, Memory Bank and git history never have two authors.

It pays for large, separate slices; on a small feature, in sequence is just as fast. Step by
step for each tool: [Parallel Work](https://github.com/GregorBiswanger/featherspec/wiki/Parallel-Work).

---

## The loop

```mermaid
flowchart LR
  S["💬 /sdd-specify<br/>interview → spec"] --> K["🔍 /sdd-clarify<br/>adversarial pass"]
  K --> P["🗺️ /sdd-plan<br/>spec → baby steps"]
  P --> R["👀 you read the plan<br/>cheapest review there is"]
  R --> A["📂 /sdd-lifecycle<br/>backlog → active"]
  A --> I["⚙️ implement<br/>step by step"]
  I --> C["✅ /sdd-compile<br/>verdict + evidence + spec fidelity"]
  C --> L["📦 /sdd-lifecycle<br/>active → done"]
  L -.->|next iteration| S
```

The spec says **what and why**. The plan says **how**, in steps small enough to verify one at a
time. Both are files, both are versioned, and a traceability table connects every acceptance
criterion to the steps, the code paths and the **test** that fulfil it.

Two of those boxes are not commands, and that is the point. `/sdd-clarify` reads your finished
spec as a stranger would — it cannot use the conversation that wrote it, which is precisely why
it finds what that conversation missed. And the plan review is yours: a wrong step costs
hundreds of lines, a wrong line costs one, so a 200-line plan is the cheapest thing you will
read all cycle.

Not every change deserves this. A typo, a config value, a one-line fix with an obvious test:
take the fast path, say that you took it, and move on. The ceremony serves the method; it is
not the method.

---

## See it work — a 5-minute example

A tiny service that splits a restaurant bill. No database, no frontend, no login — just enough
to watch one full SDD cycle go by.

### ① Say what you want — not how

```text
/sdd-specify A small service that splits a restaurant bill fairly across several people.
A user gives three things: the bill amount, a tip percentage and the number of people.
The service returns what each person pays in total, and the overall tip amount.
```

Notice what is *not* in there: no "build a REST API", no Express, no endpoint paths. Only the
problem. The agent now interviews you — one question at a time — about users, scope, edge cases
and acceptance criteria, then writes:

```text
.specs/backlog/0001-bill-splitter.md
```

### ② Add the product rules only you can decide

As a follow-up message in the same chat:

```text
Add these rules to the spec:
- 0 or fewer people returns a clear error, never a calculation.
- A negative tip percentage is rejected. 0 percent is allowed.
- A bill amount of 0 is allowed and yields 0 per person.
- Leftover rounding cents go to the first person, so the sum matches the total exactly.
```

That last rule is the point of the whole exercise. It is a **product decision** — no model can
guess it, and no developer should invent it. In the spec it becomes a testable criterion:

```text
AC-004: The service shall return per-person amounts that sum to the bill total exactly.
```

Note the shape. That rule is always true — it has no trigger and no starting point, so writing
it as "given a bill of 100 across 3 people, when…" would quietly shrink an invariant into one
example, and one example is what would get built. Criteria come in five shapes for exactly this
reason: always-true, event, state, unwanted behaviour, optional feature.

### ③ Let a second pair of eyes attack the spec

```text
/sdd-clarify
```

This reads your finished spec **as a stranger** — no conversation history, no benefit of the
doubt — and returns six short lists: contradictions, terms you used in two senses, criteria
nothing can decide, implementation details posing as intent, failure modes you never named,
and assumptions posing as decisions — then how many of them block planning. It does not fix
them on its own. It offers to walk you through them, one question at a time, with options
and a recommendation where the spec supports one; only what you confirm reaches the spec.

Thirty seconds of reading here is the cheapest ambiguity you will ever remove. Left alone, every
one of those gaps gets silently resolved by the planner's best guess and hardened into numbered
steps.

### ④ Let the agent plan the how

```text
/sdd-plan Build it as a minimal HTTP service on Node.js with the built-in http module, no
frameworks. One POST endpoint /split. The calculation lives in its own testable module.
Unit tests with the built-in node:test runner. No database, no build step.
```

This writes `0001-bill-splitter.plan.md` right next to the spec: numbered baby steps
(`T-001`, `T-002`, …), each with a `Verify:` line you can actually run and grouped into a
few **stages**, plus a traceability table and a session-handoff block. Then it **stops** —
planning never touches code.

### ⑤ Read the plan

Now open `0001-bill-splitter.plan.md` and actually read it. This is the highest-value review
minute in the whole cycle, and it is the one everybody skips.

You are not hunting for defects. You are checking that you and the agent agree on the **why**
and on the **order** — that step three really does depend on step two, that nothing important
is missing, that the risky part comes first. A wrong step produces hundreds of wrong lines; a
wrong line produces one. Two hundred lines of plan beats two thousand lines of diff.

Say which steps look wrong before anything is implemented. Approving the plan approves the
document, not the start of work — implementation begins on your explicit go ("Implement"),
and that go also moves the pair into `.specs/active/`: implementation happens there, not in
the backlog.

### ⑥ Implement, step by step

```text
Implement.
```

The agent works the next step and stops: quality gates green, the step ticked with its
recorded result, a short report, a commit proposal. Say `Implement.` again for the next one —
or ask for the whole stage or the whole plan when it should run through. The plan groups its
steps into **stages**; at a stage end plan and Memory Bank are brought level.

With the default TDD working mode, a new behaviour starts as a test you get to see fail —
and the agent stops after writing it, waiting for your go before any implementation. It then
makes one focused change, runs the step's `Verify:` line and ticks the box with the result —
the command it ran and what came back. No recorded run, no tick: that one rule keeps a plan
from becoming a list of good intentions. Traceability, the handoff and the Memory Bank are
brought level when the stage ends, not after every step. Steps joined by `‖` can run side by
side — [Work in parallel](#work-in-parallel--subagents-or-several-agents).

Before anything is called *done*, the agent reconciles plan, Memory Bank, and code — a step
whose status did not move is not finished, whatever the code looks like. Close a session
mid-way and the next one resumes from the plan file, not from your memory.

### ⑦ Check it against your own criteria

```text
/sdd-compile
```

You get a readiness brief that opens with a verdict — `READY` (with declared manual checks
counted), `NOT READY`, or `NOT READY — unverified` — followed by every acceptance criterion
marked satisfied or pending *with evidence*, the open plan steps, whether the docs are in
sync, and the next three actions.

Evidence means a test name and its output, or a command and its output. Not a step number, and
not a sentence describing the code. If the suite did not run, the verdict is `unverified` no
matter how good the criteria look — an agent grading its own homework is the one thing this
brief exists to prevent.

A green test is not the last word either: it proves that the code does what the *test* says,
and an agent that wrote code and test together made the test agree with the code. So the brief
also reads the code against each criterion's wording and runs the cases the spec itself states
— its examples, its edge cases, the boundaries its rules name. A stated case the code fails,
shown as a command and its output, marks the criterion pending, whatever the test says. Anything
the spec does not state stays a finding; the verdict is a function of your spec and your code,
so the same code gets the same verdict tomorrow. A rule check lists breaches of `AGENTS.md`'s
non-negotiables and style bullets, quoting the rule — findings for you to weigh, never verdict.

Run it yourself, in a new session — the agent never starts it on its own — and best with a
strong model from another model family than the one that implemented: a judge tends to pass
what its own family wrote.

The important discipline: you check against **the criteria you wrote**, not against a gut
feeling. If "actually I'd also like X" comes up now, that is not a bug — it was never in the
spec. That is the next iteration.

### ⑧ Close the loop

```text
/sdd-lifecycle
```

Spec and plan part ways here, deliberately. The spec moves into `.specs/done/` and stays a
living document — the starting point for iteration two, which runs faster because the
context is already written down. The plan is frozen into `.specs/plan-archive/` under a
dated name, linked from the spec's `**Plan:**` line and its `## Plan history`: one immutable
plan per iteration, never deleted — so a later change can trace exactly what each iteration
built, down to the tests to retire when a requirement goes away. The agent verifies the
moved files really left their old folder before proposing the commit.

---

## The thirteen commands

| Command | What it does |
| --- | --- |
| `/sdd-overview` | Where am I? Workflow map, current spec status, command list |
| `/sdd-setup` | One-time wizard: doc language, Memory Bank, architecture snapshot, working agreements, issue tracker |
| `/sdd-specify` | Adaptive product-owner interview → a lean, testable spec (+ optional tracker ticket) |
| `/sdd-clarify` | Adversarial pass over a spec: contradictions, ambiguity, untestable criteria, implementation posing as intent, missing failure modes; then an optional guided walkthrough of the findings |
| `/sdd-plan` | Spec → a persisted plan of baby steps, with research and traceability |
| `/sdd-compile` | Readiness check: verdict, evidence and spec fidelity per acceptance criterion, tests, rule check, docs sync |
| `/sdd-lifecycle` | Move specs between `backlog/`, `active/`, `done/` — archiving the plan at completion, syncing the ticket if linked |
| `/sdd-architecture-update` | Detect structural drift, update the snapshot (asks first) |
| `/sdd-architecture-scan` | Deep, resumable scan of an existing codebase → architecture fingerprint |
| `/sdd-reverse-specify` | Existing code, tests or a plan → evidence → your validation → a normal `Baseline` spec |
| `/sdd-style-update` | Capture a coding-style preference so it sticks |
| `/sdd-featherspec-update` | Check your template version and update safely — customizations preserved |
| `/sdd-clean` | Keep the persistent context lean: dedupe, drop stale content, compact — with a token report |

New to it? Just run `/sdd-overview`.

---

## What ends up in your repo

```text
AGENTS.md              the constitution — rules, doc language, template version, architecture snapshot
CLAUDE.md              one line: @AGENTS.md
CHANGELOG.md           the template's release history (snapshot at adoption)

.claude/commands/      the thirteen workflow bodies (Claude runs them directly)
.claude/rules/         path-scoped craft rules, loaded when a matching file is read
.claude/settings.json  auto memory off, so the Memory Bank is the only project memory
.github/prompts/       thin loaders so Copilot reaches the same bodies
.github/instructions/  thin loaders so Copilot gets the path-scoped rules too
.github/agents/        the Copilot persona, plus the scout and worker agents in VS Code dialect
.vscode/settings.json  Copilot wiring: instructions/prompts locations, local memory tool off

.specs/                backlog/ · active/ · done/ · plan-archive/ — specs, plans, frozen plan history (ships empty)
.memory-bank/          projectbrief · systemPatterns (decisions, patterns, knowledge records) · techContext · activeContext
```

A deep scan may add one more: `.architecture/` — optional curated per-module maps, created
only when the snapshot's line cap would otherwise evict navigation detail.
Reverse specification works in `.sdd-reverse/` — a capability worklist and the candidates
awaiting your validation; a promoted candidate leaves it, and nothing there is ever auto-loaded.

Everything mutable lives in `AGENTS.md` and the two data folders. Workflow bodies exist exactly
once, under `.claude/commands/`; `.github/prompts/` holds thin pointers to them.

There is one deliberate exception, and it is labelled everywhere it occurs: a path-scoped rule
only loads once a matching file has been **read**, so a brand-new spec or plan would be written
without its rule in context. The commands that create those files restate three essentials
inline, and each rule file says why. Don't "clean up" that duplication — it is load-bearing.
Where a copy exists, it names `AGENTS.md` as the winner.

---

## Why one template for two tools

- **VS Code Copilot reads most of Claude Code's configuration.** `AGENTS.md` natively, via
  `chat.useAgentsMdFile`; the path-scoped rules through eight thin loaders in
  `.github/instructions/`, whose `applyTo` globs mirror each rule's `paths:` — the rule text
  itself stays single-source under `.claude/rules/`. FeatherSpec leans on the overlap
  instead of maintaining two copies.
- **Workflows are commands, not skills.** A skill advertises itself to the model on every
  request; a command is only ever run when *you* type it. Ten workflows sitting in every
  system prompt is a cost with no upside here.
- **Only the entry point differs.** `.claude/commands/<name>.md` holds the body;
  `.github/prompts/<name>.prompt.md` is a thin pointer to it (its frontmatter mirrors the
  body's — declared in `AGENTS.md`, which wins on divergence). One body to edit, two tools
  served.

The [full interop matrix](https://github.com/GregorBiswanger/featherspec/wiki/Interop-Matrix)
spells out exactly what each tool reads, with caveats and sources.

---

## Learn more

Everything beyond this page lives in the **[Wiki](https://github.com/GregorBiswanger/featherspec/wiki)**:

| Page | What's in it |
| --- | --- |
| [Getting Started](https://github.com/GregorBiswanger/featherspec/wiki/Getting-Started) | Setup for both tools, verifying what actually loaded |
| [Commands](https://github.com/GregorBiswanger/featherspec/wiki/Commands) | Every `/sdd-*` command in detail |
| [Updating & Versioning](https://github.com/GregorBiswanger/featherspec/wiki/Updating-and-Versioning) | Check your version, update safely, what never gets touched |
| [Issue Tracker Link](https://github.com/GregorBiswanger/featherspec/wiki/Issue-Tracker-Link) | Link specs to Jira or GitHub Issues — setup per tool, what syncs when |
| [Specify Method](https://github.com/GregorBiswanger/featherspec/wiki/Specify-Method) | The interview model behind `/sdd-specify` — origin and deliberate deviations |
| [Specs & Plans](https://github.com/GregorBiswanger/featherspec/wiki/Specs-and-Plans) | Document structure, lifecycle, traceability |
| [Parallel Work](https://github.com/GregorBiswanger/featherspec/wiki/Parallel-Work) | Subagents, a second session, another tool or a worktree on one plan — step by step |
| [Memory Bank](https://github.com/GregorBiswanger/featherspec/wiki/Memory-Bank) | The four files and what belongs in each |
| [Interop Matrix](https://github.com/GregorBiswanger/featherspec/wiki/Interop-Matrix) | What Copilot reads from `.claude/`, with sources |
| [Configuration](https://github.com/GregorBiswanger/featherspec/wiki/Configuration) | Shared vs. local settings, auto memory, MCP, hooks |
| [Extending FeatherSpec](https://github.com/GregorBiswanger/featherspec/wiki/Extending-FeatherSpec) | Add your own commands and rules |
| [Hands-On Walkthrough](https://github.com/GregorBiswanger/featherspec/wiki/Hands-On-Walkthrough) | The full workshop exercise, PO/Dev in pairs |
| [Troubleshooting](https://github.com/GregorBiswanger/featherspec/wiki/Troubleshooting) | Commands not showing up, rules not applying |
| [Committing to One Tool](https://github.com/GregorBiswanger/featherspec/wiki/Committing-to-One-Tool) | Strip out the other tool later, mechanically |

Coming from `copilot-spec-driven-template`? See
[Migration](https://github.com/GregorBiswanger/featherspec/wiki/Migrating-from-copilot-spec-driven-template).

---

<div align="center">

Built by [Gregor Biswanger](https://github.com/GregorBiswanger) · MIT licensed · Issues and PRs welcome

</div>
