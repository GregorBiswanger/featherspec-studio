# Changelog

All notable changes to the FeatherSpec template are documented here.

> In a derived project this file is a snapshot at adoption — the template never updates it
> there. The living changelog is the template's
> [GitHub Releases page](https://github.com/GregorBiswanger/featherspec/releases).

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) · Versioning:
template-semver — **MAJOR** means derived projects need a real migration step, **MINOR**
means additive capability that merges into a customized project, **PATCH** means wording and
docs fixes that are safe to overwrite.

## [1.10.0] - 2026-11-15

### Changed

- **Plan work with lean bookkeeping: upkeep no longer rides on every step.** The
  criticism was that working through a plan took too long. Measured on the benchmark tasks,
  the time went neither into the quality gates nor into the code: it went into the number of
  small steps and into the upkeep each one triggered — about three plan edits plus a
  dashboard refresh per step. Three changes follow. **Steps are behaviour slices**: the test
  and the code for the criteria the same tests decide, typically three to five, never split
  by layer or file; docs sync and the final gate run form one closing step. **Per finished
  step, one edit**: the checkbox now sits on the `Verified` line and carries the step ID, so
  the tick and its recorded result are a single unambiguous edit — still no tick without a
  recorded run. Traceability rows, the plan handoff and `activeContext.md` are brought level
  when a stage ends, when work is blocked, and before anything is reported as done.
  **Stages** (`## Stages` in the plan) group steps that need no human decision in between;
  the stage end is where plan and Memory Bank are brought level. Work still stops after
  every step — gates green, the tick, a short report, a commit proposal — and a whole stage
  or the whole plan runs in one go only when you ask for it. A stop a working agreement asks
  for, the test review above all, is never skipped, moved or collected in advance: the yes
  that counts is the one given to the tests as written.
  `/sdd-architecture-update` no longer adds a stop of its own inside plan work: snapshot
  entries the approved plan names are confirmed by that approval. The *Quality gate* and
  *TDD* working agreements are untouched — the gates still run before every tick (in
  sequence after every step; in a parallel stage once, on the combined result, before any
  of its steps is ticked), and a TDD stop still stops. Replayed against 1.9.0 on the released
  wording — same approved
  spec (17 criteria), same model, in a sandbox, the whole plan requested in one go, three
  runs each side by side: implementation time fell from a median of 294 s (286 · 294 · 342;
  nine or ten steps and one confirmation stop per run) to 204 s (194 · 204 · 232; five
  steps, no stop) — about 30 % less. Hidden acceptance tests passed 26/26 in all six runs
  and every 1.10.0 plan ended complete with a recorded run per step. Earlier series on
  draft wordings showed a larger gap — 437 s against 232 s on the same feature, where the
  1.9.0 plans had eleven or twelve steps and the reply latency at the stop was counted,
  and about 720 s against 480 s on a brownfield task with a session switch, where the
  handoff after the switch was correct. Small samples, one model, two small JavaScript
  projects — a direction, not a guarantee.
- `AGENTS.md` stays at 200 lines: the sync gate was rewritten in place.
- **`/sdd-compile` is the user's command.** A finished plan stops with a recommendation and
  the agent never starts the readiness check on a "continue". The recommendation names how
  it is strongest: a new session, a strong model from another model family than the one
  that implemented — a judge tends to pass what its own family wrote.
- `/sdd-setup` closes by saying that the next commands belong in a new session — the one
  that ran setup was opened with the `AGENTS.md` from before it.

### Added

- **Parallel work on one plan, without a coordinator.** `/sdd-plan` looks for independent
  steps in every plan and joins them with `‖` — separate files (a `Files:` line each),
  separate tests, a shared file in its own step before or after them, each check passing
  without the other — and closes the stage list with what it found (`Parallel: stage 2.`,
  or `No parallel stage:` and the reason). Such a stage can run in sequence, with subagents,
  or be handed to other agents: a second session, another tool or model, a git worktree.
  The agent asks once per plan, says what each way changes and recommends one. One rule
  keeps all of these conflict-free: the main session is the only writer of the plan,
  `activeContext.md` and git history; a worker writes only its own step's files and one
  return note, `.memory-bank/activeContext.<spec>-<step>.md`. The main session re-runs each
  `Verify:`, runs the gates on the combined tree, ticks the steps and deletes the notes; a
  note left lying around means parallel work came back and is not integrated, and
  `/sdd-overview` and `/sdd-lifecycle` say so. A session is a worker when it was started
  with the worker line or told that another session is on the plan; asked for a step whose
  earlier steps are still open in its checkout, it asks which it is. A worker checks its
  base first and never writes outside its checkout: a worktree holds committed files only,
  so the main session proposes the commit that brings the tree level before it hands out
  the start lines, and the worker's result comes back as one commit on its branch. New:
  `.claude/rules/parallel-work.md` with
  its loader (loads only when a return note is touched), and the `sdd-implementer` agent in
  both dialects — give it another `model:` to put workers on a different model. Verified
  with four concurrent worker sessions in one working tree (the *other agents* route), one
  of them on a different model: no
  write to the plan or the dashboard, all four notes integrated and removed, hidden tests
  green. On a task this small parallel work was not faster than working in sequence — it is
  for slices that are large and separate. Also exercised: two workers in their own git
  worktrees created from the stage commit — each came back as one commit on its branch,
  the main session merged, re-ran both checks and the gate, and only then ticked — and a
  session started in free words in a worktree that lacked the earlier stage: it changed
  nothing, named the missing base and asked which it was. Subagents ran end to end in
  Claude Code 2.1.296 and have not been exercised in GitHub Copilot yet: the main session
  delegated a two-step stage to two `sdd-implementer` workers at the same time, then
  checked the changed files, ran both checks and the gate itself and ticked. A complete
  parallel stage in Copilot is still to be exercised as well.
- **Tracker drift check** (#20, #23): the tracker is where reality changes between two SDD
  sessions — a colleague closes a ticket, a product owner reopens one — and until now the
  next lifecycle move wrote its transition over whatever was there. `/sdd-lifecycle` now
  reads the ticket's state before it writes: already in the target state → it says so and
  skips the redundant transition; ahead of the spec ("Done" while the spec is still
  `In Progress`) → it names that and asks again before anything moves — a hint, never
  evidence, and a move into `done/` stays gated on `/sdd-compile`; reopened → the normal
  transition plus the reactivation proposal; unreadable → drift is unknown and the move
  proceeds as before. `/sdd-overview` offers to compare all linked tickets and then shows
  one line per ticket whose state differs from its spec. Findings and proposals only: no automatic
  move, no polling, no new setting, no
  new file. Designed and implemented by @TheEifelYeti. Two adjustments on top, both from
  the constitution's Ask-first rule for network commands: in `/sdd-lifecycle` the read
  happens right after the yes to the move instead of before the proposal (that yes covers
  it, so the usual case still takes one answer); `/sdd-overview` offers the comparison once
  at the end of its report instead of reading unasked, and uses one query where the tracker
  allows. Exercised against
  a GitHub test double in seven runs: target state, normal transition, tracker ahead (three
  times), tracker unreadable, and the overview comparison.
- **Guided walkthrough in `/sdd-clarify`** (#24): a long report leaves the user alone with
  the hard part — which finding first, and what to do about it. The six lists stay and stay
  first, now one or two lines per finding, followed by the count ("9 findings, 5 block
  planning") and the verdict. Then one offer — in the tool's question picker where it has
  one: go through the findings one at a time. Each
  message is one finding — the quote, what goes wrong if it stays open, two to four options
  with their consequences. An option is marked recommended only where the spec, `AGENTS.md`,
  the Memory Bank or the code supports it, with the support named; without a basis it says
  so. The user picks, answers in their own words (read back before it counts), skips, or
  stops; blocking findings come first, then one check-in whether to go on. Only confirmed
  decisions are written into the spec, in one pass, the way `/sdd-specify` revises; skipped
  and unreached findings land in *Open points* as open questions. No findings, no offer.
  The command still never resolves anything on its own — finding stays the stranger's job,
  deciding stays the user's. A finding that rests on `AGENTS.md` is checked against the file
  on disk before it is listed: a session opened before `/sdd-setup` still holds the old one.
  Compared with 1.9.0 on a spec with six seeded defects (three
  runs of 1.9.0, four of the released wording): all six found in every run of both
  versions; 15–19 findings per report against 20–24, the old form often listing one defect
  under two or three headings.
- **Unknown settings keys are named** (#21): a misspelled key in the `AGENTS.md` settings
  block is not an error — `IssueTrackr: jira` simply behaves like `IssueTracker: none`, and
  nothing says why ticket sync never runs. `/sdd-overview` now names a key the constitution
  does not declare, a near-miss together with the key it resembles; `/sdd-setup` and
  `/sdd-featherspec-update` propose rename, remove or keep. Nothing is fixed unasked; no
  schema, no strict mode, no new setting. Proposed by @TheEifelYeti. Exercised in all three
  commands, the updater as part of the 1.9.0 → 1.10.0 rehearsal.

## [1.9.0] - 2026-09-27

### Changed

- **`/sdd-compile` checks spec fidelity, not only evidence** (#16): a green test proves that
  the code does what the *test* says — not what the *spec* says, and an agent that writes code
  and test together makes the test confirm the code. The readiness brief now reads the code
  each traceability row names against the criterion's wording and runs the cases the spec
  itself states — its Given/When/Then examples, the edge and problem cases of its catalogue,
  the boundaries its business rules name. A stated case the code fails, shown as a command
  plus its output, makes that criterion `pending`: its test proved the test, not the
  criterion. Inputs the spec does not state — exploratory magnitudes, encodings — are
  findings, never verdict material, so a re-run on an unchanged repository still returns the
  same verdict. The scope check also names behaviour in the diff that no criterion and no
  plan step ordered, not only unmappable tests, and a new rule check reports breaches of the
  Non-negotiables and the *Style & Output Preferences* bullets — findings, never verdict; the
  four blocker classes stay exactly four. Nine lines in one command, no new command, no new
  setting, `AGENTS.md` unchanged at 200 lines. Designed by @TheEifelYeti as a two-axis
  `/sdd-review` command, folded into the gate on review, and verified with seeded defects on
  a finished project: 1.8.0 certified a half-down rounding defect whose tests had been bent to
  match as `READY`; 1.9.0 returns `NOT READY` with the spec's own example as the counterexample.

## [1.8.0] - 2026-09-25

### Added

- **Reverse specification** — `/sdd-reverse-specify [target]` (#14): reconstructs existing
  behaviour from code, tests, contracts or a technical plan into a **human-validated**
  `Baseline` spec. Works on a file, folder, symbol or plan, or on the whole application via
  the architecture fingerprint. It proposes a capability map in domain language first (a
  technical module is never a spec boundary), sends isolated `sdd-reverse-scout` agents to
  collect evidence for one capability at a time, and writes a temporary
  `.sdd-reverse/candidates/*.reverse-spec.md` whose rules carry `[Inferred]` or `[Uncertain]`
  — never a percentage. Before anyone sees the candidate, a check scout tries to prove every
  rule, criterion and finding wrong in the code, and synthesis walks its reports once more so
  that no limit, rounding direction, ordering or unchecked bound is left behind.
  Validation checks understanding, never intent: each question states
  what the system does today and asks whether that is how the person knows it — conflicts
  first, uncertain behaviour next, inferred behaviour as batched confirmations; nobody is
  asked what the system should do, and `[Confirmed]` comes from a human alone. Nor is anyone
  asked about what they could not have seen — a retry count, a stored value, the order two
  things happen in: those are shown, not asked, and stay in the spec on their evidence. A
  marker reports how clearly the code settles a statement, never how much of it a person
  recognised, so "don't know" leaves it as it is and the promoted spec says in one line which
  IDs a person confirmed and which rest on the code alone. Behaviour that
  could harm or mislead a person, and checks the code does not make, become *findings*
  stated as their consequence — never a rule; so does a belief the code contradicts.
  Conflicts between description, plan, tests and code are shown, never resolved silently;
  unreferenced code never becomes a rule. Questions and criteria stay in business language;
  text people see is quoted exactly as the code has it. Promotion writes a normal spec to
  `.specs/done/` (`Status: Baseline`, `Plan: _none_`, `Origin`, `Validated by`, a
  `Technical Reference` of at most eight lines) — no retrospective plan, no parallel
  lifecycle. A `Clarified:` line records the `/sdd-clarify` read that is due before a change
  is planned against a Baseline, and `/sdd-plan` refuses to plan one without it. Scouts never
  copy a password, token, key or connection string out of the code — the place becomes a
  developer check instead. Resumable from its files at any point.
- `/sdd-setup` offers reverse specification once, at the end of the existing-software path,
  with recommended starting areas derived from the confirmed snapshot. Declining changes
  nothing; the wizard holds no reverse logic of its own.
- `/sdd-overview` reports open reverse candidates.

### Changed

- `/sdd-specify` no longer reconstructs existing behaviour itself: its former *Baseline mode*
  now delegates to `/sdd-reverse-specify`, the single home of that workflow.
- A changed `Baseline` now has a defined path: `/sdd-lifecycle` reactivates it like an
  `Implemented` spec, and `/sdd-plan` Mode C builds its impact report from the spec's
  *Technical Reference* instead of an archived plan, then writes its first plan. Before, a
  Baseline could only be followed by a successor spec.
- `AGENTS.md` is back under its 200-line cap: three lines of explanatory prose were
  tightened to make room for the new command row.

## [1.7.0] - 2026-09-19

### Added

- **Issue tracker link** (opt-in): `/sdd-setup` asks one last question — where tickets live
  (GitHub, Jira, another tracker, or nowhere; default `none`) — and records it as
  `IssueTracker:` in the managed settings block. When set, `/sdd-specify` offers to create a
  ticket for the finished spec and `/sdd-lifecycle` names the matching ticket transition in
  its move proposal (active, done, reactivation, deprecation) — one yes covers move and
  transition, the network write stays Ask-first, and a tracker failure never blocks the SDD
  flow. The link is one optional `**Ticket:**` line in the spec header. FeatherSpec ships no
  tracker API knowledge: the agent uses whatever is connected (`gh`, the GitHub or Atlassian
  MCP server, or the tracker's own). Teams that want every status change synced add one
  bullet to *Style & Output Preferences*; everyone else pays one line of context. Designed
  and verified by @TheEifelYeti (#15).

### Changed

- `/sdd-plan`'s start signal keeps a pending ticket transition behind the Ask-first gate,
  like the commit.
- `/sdd-setup`'s budget check counts every line of `AGENTS.md`, blank lines included, and
  names the counting commands — PowerShell's `Measure-Object -Line` drops blank lines and
  let an over-budget file pass as under the cap.

## [1.6.0] - 2026-08-29

### Added

- **Knowledge records**: `/sdd-architecture-scan` now separates what it can *see* from why it
  was *meant* that way. An observation carries at least one evidence path; its rationale is
  either `decided` — with provenance naming the ADR, the requirement document or the human
  who confirmed it — or `unknown`. Records live as small YAML blocks in
  `.memory-bank/systemPatterns.md`; every other artifact references them by id. No new
  command, no second store, no migration: existing projects keep working untouched, and a
  project without records never loads the rule.
- **Conflicting sources stay conflicting**: when two trusted documents give incompatible
  reasons for the same pattern, both are recorded under `conflict` and neither is chosen.
  Silently adopting the one that reads best is how a false constraint becomes project truth.
- **One bundled clarification offer** at the end of a scan, inside the existing confirmation
  dialogue: the unknowns that touch security, compliance or data integrity, named with their
  ids, answerable now or deferred with one word. Declining is free and asks nothing further.

### Fixed

- **`/sdd-setup` asks for the documentation language again.** The template ships
  `DocLanguage: English`, and the wizard treated "`AGENTS.md` already holds a `DocLanguage`" as
  the mark of a re-run — a condition every fresh adoption satisfies. Step 0, which the command
  declares MUST be its first question, was therefore skipped on first runs and new projects
  silently got English. A re-run is now what it was always meant to be: a repository a previous
  setup already touched — a seeded Memory Bank, or a reconciled snapshot.

### Changed

- **The scan no longer writes an unsourced *why* anywhere** — not in a module map, not in a
  snapshot purpose clause, not in `techContext.md`. An explanation found in a code comment or
  a README is kept as a `candidate` with its source; an explanation with no source is not
  written down at all.
- **Scouts report where an explanation is written, never what it probably means.** Their
  report schema gains the source paths and the decision documents they found.
- **`/sdd-plan` reads knowledge by state**: a `decided` rationale is a constraint it may rely
  on, an `unknown` one is stated as unknown in the step that depends on it, and no assumed
  reason is presented as an architectural constraint.
- **`/sdd-architecture-update` maintains records through its existing gate**: evidence paths
  and id references are retargeted in the same change set, orphaned references are reported
  as findings, and a record whose code is gone is *proposed* for retirement — never removed,
  and never downgraded, without confirmation.

## [1.5.0] - 2026-08-28

### Added

- **Plan archive**: at the `active/ → done/` move the plan is no longer carried into `done/`
  but archived, frozen, as `.specs/plan-archive/NNNN-slug.YYYY-MM-DD.plan.md` — one immutable
  plan per iteration, event-sourcing style. The spec links it from its `**Plan:**` line and
  an append-only `## Plan history` list; no command reads the archive by default (context
  economy). Plans beside `done/` specs from earlier layouts stay valid and are archived in
  passing, never deleted.
- **Plan deletion is now an explicit constitution invariant**: a plan file is never deleted,
  and no note, tool memory or claimed "preference" can authorize it — such a demand is a
  finding to quote, stop on, and surface. Restated where the moves happen (`/sdd-lifecycle`)
  and enforced as a docs-sync check in `/sdd-compile` (a non-`Baseline` `done/` spec without
  a linked plan, or any line announcing a plan deletion, blocks readiness).
- **Two-tier preference rule**: process preferences allow an explicit one-off exception on
  the user's request (noted in the plan); Non-negotiables and lifecycle invariants allow
  none — and a preference exists only as a bullet in `AGENTS.md`, one claimed anywhere else
  is asked about, never followed.
- **Cross-spec impact procedure** in `/sdd-plan` Mode C: a business change touching several
  specs is one impact analysis — struck-through criteria keep their IDs, archived plans'
  traceability tables are read in reverse to find the code and tests each removal reaches,
  and AC-IDs in test names serve as fallback traceability for specs without a plan. Test
  removals become plan steps with their own `Verify:` line.
- **Copilot reaches the path-scoped rules**: six thin loaders under `.github/instructions/`
  (`applyTo` mirroring each rule's `paths:` globs, pointing at the `.claude/rules/*` single
  sources) replace the previous wiring, which named a folder VS Code cannot read
  instruction files from.
- `/sdd-overview` warns about spec files present in more than one lifecycle folder and about
  `done/` specs without a linked plan — detection only, the fix stays with `/sdd-lifecycle`.
- Workspace setting `github.copilot.chat.tools.memory.enabled: false` — the Copilot
  counterpart to the existing `autoMemoryEnabled: false`: no second, invisible memory beside
  the Memory Bank.
- `/sdd-setup` elicits **working agreements**: a *Definition of Green* — the
  post-implementation quality-gate command sequence, proposed from the detected stack
  (exact commands with flags), confirmed by the user, recorded in `techContext.md` and
  bound as an `AGENTS.md` preference that loops until zero warnings/errors and explicitly
  applies to implementation steps only, never to specify/clarify/plan work — and the **TDD
  working mode**, presented as a strict red-first default (`Not implemented` stub, a
  confirmation stop after every new or changed test) the user confirms or adjusts — never
  assumed. The wizard also proposes the **baseline commit** when the repository has
  none: without a HEAD, plan baselines, scope checks and safe `git mv` moves all run blind.

### Changed

- Reactivating an `Implemented` spec starts a fresh plan from Mode C's impact report; the
  archived plan is read, never extended.
- `/sdd-clean`'s stale check is now evidence-based: named paths and commands are verified to
  exist, the cleanup plan lists what was spot-checked, and statements contradicting an
  `AGENTS.md` invariant are corrected (in scope) or reported (outside it) instead of being
  preserved as facts.
- Memory Bank rule: `activeContext.md` is updated by replacement, not accumulation —
  "Changed Recently" holds at most ~6 bullets, "Validation" replaces its previous line, and
  a completed spec resets the file to its skeleton (`Current phase: idle`, real links to
  the done spec and archived plan).
- `/sdd-compile` gained an expected-state definition and a verdict rubric: the state it
  certifies is spec `In Progress` in `active/` with its plan `Done` beside it — never a
  finding, and the `done/` move is never a readiness fix (the move *follows* `READY`;
  demanding it first is circular). Blockers are exactly four: criterion without evidence ·
  failing/unrun gate · plan/traceability hole · a working document contradicting the code
  or a constitution invariant. Historical process deviations and pending user acceptance
  are findings, and a re-run on an unchanged repo returns the same verdict. Its docs-sync
  check also scans `.specs/` for stray copies, including resurrected plans.
- `/sdd-plan`: approval of the plan approves the document, never the start of work —
  implementation waits for the user's explicit start signal. Steps carry a size rule of
  thumb (one or two criteria per step), owned by `.claude/rules/plans.md`.
- `/sdd-lifecycle` move mechanics hardened: moves run as `git mv` (atomic, staged) with an
  untracked-files fallback that proposes the missing baseline commit; the final check is a
  file-system listing run as the very last action, with `git status --short` additionally
  matched against the expected list where a HEAD exists; the hand-off always warns to close
  pending editor buffers (a later "save all" recreates moved files at their old path) and
  points at `/sdd-overview` — whose warning also catches stray plans — as the re-check.
  The freeze edit rewrites the archived plan's `**Spec:**` backlink to `../done/`.
- `/sdd-specify` re-checks the whole spec's language (acceptance criteria included) against
  `DocLanguage`; `/sdd-style-update` normalizes bullets to English (`AGENTS.md` is wiring);
  the constitution cap triggers one eviction proposal, not a recurring negotiation.
- `/sdd-setup` opens language-first: at most two English sentences, then the `DocLanguage`
  question — the full SDD orientation and command table follow entirely in the chosen
  language (the definition is translated, not quoted in English). The quality-gate and TDD
  questions are written for newcomers: the gate question explains in plain words why linter
  and tests run after every implementation step, and the TDD question presents a **default**
  instead of a quiz — red-first via `Not implemented` stubs for new behaviour, a stop after
  every new or changed test for the user's confirmation before implementing,
  immediately-green tests against existing code allowed with a negative control where it
  is cheap. Neither question is ever answered by assumption.
- `/sdd-plan` proceeds automatically only when exactly one candidate spec exists (and says
  so); with several it lists and asks — never a silent pick.
- `/sdd-lifecycle` acts **move-first, edit-second**: metadata edits happen at the
  destination path after `git mv`, so no dirty editor buffer remains at the source path —
  the mechanism behind every observed post-move duplicate (only files edited before their
  move ever resurrected).
- Onboarding & interview UX: `/sdd-setup` opens under a 🪶 FeatherSpec banner, prefers the
  client's structured question UI, bundles everything derivable into one
  "here is what I derived" confirmation with named sources ("from `package.json`", never
  "from your notes"), and asks only the genuinely open steps one at a time. `/sdd-specify`
  renders questions as plain markdown (never code fences), attaches answer suggestions,
  and pins the product-owner stance: business questions only — the technical form lands in
  *Technical notes* and is decided in `/sdd-plan`, unless the user speaks technically first.
- Grounding in `/sdd-plan`: with a web search/fetch tool available, looking facts up is the
  preferred path over recall — a version-sensitive fact is never quietly downgraded to an
  assumption to skip the lookup (the Ask-first research batch is unchanged); without any
  web tool, affected steps become assumptions plus ready-made search queries for the user.
- An explicit start signal ("implement", "start T-001") also covers the still-pending
  backlog → active move: the agent performs it per `/sdd-lifecycle`'s procedure and says so.

## [1.4.0] - 2026-08-27

### Added

- `/sdd-clean`: context cleanup for FeatherSpec's persistent markdown — analyzes every
  managed file against its declared purpose, detects verbosity, duplicates, stale and
  code-rediscoverable content, previews a cleanup plan behind one gate, compacts
  semantically (decisions, constraints and conventions are always preserved), and reports
  estimated tokens before → after. Snapshot drift hands over to
  `/sdd-architecture-update`'s gate; specs and plans get report-only findings. Re-running
  is safe: already-optimized files are left untouched.
- `/sdd-architecture-update` recommends `/sdd-clean` when the Memory Bank has visibly
  outgrown its purpose — cleanup itself never runs as a side effect.

## [1.3.0] - 2026-08-27

### Added

- `/sdd-plan` opens with a software-architect persona and, where the tool supports
  subagents, delegates each research lookup to an isolated agent — only distilled,
  source-backed findings enter the planning context.
- Plans name their **quality gates**: the Approach block lists the test/build/lint commands
  from `techContext.md`, step Verify lines draw on them, and the final step runs them all.
- Bidirectional spec ↔ plan linkage: specs carry a `**Plan:**` line under their status,
  maintained by `/sdd-plan`; plans already linked their spec.
- `/sdd-lifecycle` gains the reactivation move: an `Implemented` spec whose behaviour
  changes moves back to `active/` after `/sdd-plan` Mode C's impact report.

### Changed

- The plan's Approach block records chosen technologies with a one-line rationale each;
  long-lived decisions go dated to `systemPatterns.md`.

## [1.2.0] - 2026-08-26

### Added

- Versioning: the template carries a `FeatherSpecVersion:` stamp in `AGENTS.md`'s managed
  settings block; releases are annotated git tags surfaced as GitHub Releases, recorded here
  and in the version ledger.
- `/sdd-featherspec-update`: check the installed template version (`check` mode works even
  on customized, unstamped projects via feature probes) and update safely — fetches the
  recorded base and the target release as real trees, classifies every file by canonical-hash
  three-way comparison, previews everything before writing, migrates around preserved
  customizations, surfaces conflicts instead of choosing sides, keeps a rollback point,
  validates the result mechanically, and moves the version stamp only after success.
  Resumable at any point; re-running after success is a free health check.
- Version ledger: an append-only appendix in the update command's body recording
  per-release semantic migration knowledge back to 0.1.0 — renames, key migrations, slot
  edits, data notes, semantic flips, and version probes for unstamped projects.

### Changed

- `AGENTS.md`: the managed settings block gains the version stamp and is now managed by
  `/sdd-setup` and `/sdd-featherspec-update`; the `DocLanguage` comment is condensed to one
  line to keep the constitution under its line target; `.sdd-update/` joins the volatile,
  gitignored working locations.

## [1.1.0] - 2026-08-26

### Added

- `/sdd-architecture-scan`: deep, resumable, budget-cascaded analysis of an existing
  codebase producing an architecture fingerprint — brownfield onboarding for both Claude
  Code and GitHub Copilot.
- `sdd-scout` explorer subagent for both tools (`.claude/agents/sdd-scout.md`,
  `.github/agents/sdd-scout.agent.md`).
- Path-scoped rule for curated module maps (`.claude/rules/architecture-map.md`).
- Scan-only locations: `.architecture/` (curated module maps) and `.sdd-scan/` (volatile
  working state, gitignored).
- `/sdd-setup` asks new-vs-existing project and routes existing software into the deep scan.
- The architecture snapshot header tracks the last deep scan alongside the last
  reconciliation.

### Changed

- `/sdd-architecture-update` recommends `/sdd-architecture-scan` instead of guessing when
  drift is too large or the area is unmapped.
- Constitution eviction rules: gates, ask-first boundaries and non-negotiables may never be
  evicted from always-loaded context.
- README: brownfield onboarding path documented up to enterprise scale.

## [1.0.0] - 2026-08-04

### Added

- Always-loaded **Progress & state sync gate**: plan checkbox, traceability row and
  `activeContext.md` must move in the same change set as the code; "done" requires plan,
  active context and code to agree.
- `projectbrief.md` wired into the working loop: `/sdd-specify` and `/sdd-compile` read and
  reconcile against it.

### Changed

- Architecture updates now run **unprompted**: agents execute `/sdd-architecture-update`
  themselves in the same change set on structural drift (previously: propose and wait).
- All commands hardened against audit findings: tightened gates in `/sdd-clarify`,
  `/sdd-compile`, `/sdd-lifecycle`, `/sdd-plan`, `/sdd-specify`, `/sdd-setup`,
  `/sdd-style-update`.
- Preference capture triggers in any language and on "remember this"-style requests.

### Removed

- `docs/history/` (the template's own build specs): the template ships fully blank.

## [0.4.0] - 2026-08-03

### Added

- `/sdd-clarify`: adversarial pass over a finished spec — contradictions, ambiguity,
  untestable criteria, implementation posing as intent, missing failure modes — ending in
  one question.
- Closed verification chain: criterion → step → code → test → `Verified:` → verdict. Plan
  steps carry a `Verified:` field; traceability gains a Test column and the state vocabulary
  `open | built | verified`.
- Five acceptance-criterion shapes (always-true, event, state, unwanted behaviour, optional
  feature) with shall/should discipline and a falsifiability test.
- Non-negotiables gain an **Ask first** tier and a documented **fast path** for changes
  smaller than their spec.
- Project logo.

### Changed

- `/sdd-compile` re-derives readiness from the repository, not from ticked checkboxes, and
  returns NOT READY when the suite did not run.
- `/sdd-lifecycle` requires recorded evidence before a spec moves to `done/`.
- Copilot persona reduced to a thin loader; drifted rule copies removed.
- README rewritten for fast onboarding; detail moved to the wiki.
- The template's own build specs moved out of `.specs/done/` so a fresh clone starts with an
  empty spec numbering.

## [0.3.0] - 2026-08-03

### Added

- Persisted plans: `/sdd-plan` writes `NNNN-slug.plan.md` beside its spec — baby steps with
  per-step Verify lines, a current-step pointer, a handoff block and a
  criteria→steps→code traceability table; three modes (plan, resume, re-plan).
- Plan upkeep rule (`.claude/rules/plans.md`); `/sdd-lifecycle` moves spec and plan as a
  pair.
- `.github/prompts/*.prompt.md` thin loaders giving GitHub Copilot slash commands.

### Changed

- **Breaking (pre-1.0):** command bodies moved from `.claude/skills/*/SKILL.md` to
  `.claude/commands/*.md`; skills removed entirely so no command description is ever
  advertised to the model. `.vscode/settings.json` swaps `chat.agentSkillsLocations` for
  `chat.promptFilesLocations`.

## [0.2.0] - 2026-08-03

### Changed

- `/sdd-specify` became an adaptive product-owner interview producing a lean spec with
  testable acceptance criteria.

## [0.1.0] - 2026-08-03

### Added

- Initial shared-source hybrid SDD template: one constitution (`AGENTS.md`) loaded by Claude
  Code and GitHub Copilot through thin loaders.
- Eight `/sdd-*` workflows (overview, setup, specify, plan, compile, architecture-update,
  lifecycle, style-update) as shared skills.
- Path-scoped rules (constitution, memory-bank, repo-docs, specs), Memory Bank seed files,
  spec lifecycle folders (`backlog/`, `active/`, `done/`), Copilot agent persona, MIT
  license.

### Fixed

- Interop matrix corrected against current VS Code documentation.
- Rule duplication removed so the single-source promise holds.
- `.gitignore` for local agent configuration.

[1.10.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.9.0...v1.10.0
[1.9.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.8.0...v1.9.0
[1.8.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.7.0...v1.8.0
[1.7.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.6.0...v1.7.0
[1.6.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.5.0...v1.6.0
[1.5.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.4.0...v1.5.0
[1.4.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.3.0...v1.4.0
[1.3.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/GregorBiswanger/featherspec/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/GregorBiswanger/featherspec/compare/v0.4.0...v1.0.0
[0.4.0]: https://github.com/GregorBiswanger/featherspec/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/GregorBiswanger/featherspec/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/GregorBiswanger/featherspec/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/GregorBiswanger/featherspec/releases/tag/v0.1.0
